#!/usr/bin/env bash
# ════════════════════════════════════════════════════════════════════════
#  launch.sh — Démarre Cousin Runner en une commande
#  Usage : bash launch.sh          (démarre + ouvre le navigateur)
#          bash launch.sh serve    (démarre sans ouvrir le navigateur)
#          bash launch.sh stop     (arrête les runners)
# ════════════════════════════════════════════════════════════════════════
set -Eeuo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LOCAL_BIN="$HOME/.local/bin"
export PATH="$LOCAL_BIN:$PATH"

# Mode stop
if [[ "${1:-}" == "stop" ]]; then
  cousin stop 2>/dev/null || true
  pkill -f "[l]lama-server" 2>/dev/null || true
  echo "Arrêté — le port 11434 d'Ollama n'a jamais été touché."
  exit 0
fi

# Auto-install si cousin absent
if ! command -v cousin >/dev/null 2>&1; then
  echo "[*] Premier lancement : installation..."
  bash "$SCRIPT_DIR/install.sh"
fi

# Démarre
if [[ "${1:-}" == "serve" ]]; then
  exec cousin serve
else
  exec cousin web
fi
