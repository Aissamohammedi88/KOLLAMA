# 🕊️ Cousin Runner v2.0 — Le killer d'Ollama

Runner LLM local en Python pur. Remplace Ollama avec une identité propre :
**port 11435** (jamais 11434), home `~/.cousin`, binaire `cousin`.

## Pourquoi Cousin ?

- **Aucune dépendance** — Python 3 stdlib uniquement, aucune compilation.
- **N'importe quel modèle** — tout GGUF de HuggingFace, ou dépose un `.gguf` dans `~/.cousin/models/`.
- **WebGUI custom** — interface web intégrée sur http://localhost:11435
- **API Ollama-compatible** — `/api/tags`, `/api/chat`, `/api/generate`, `/api/ps`, `/api/pull`, `/api/show`, `/api/delete`
- **Mémoire persistante** — SQLite, injectée dans chaque conversation.
- **Multi-modèles** — plusieurs runners simultanés (11435, 11700+...).

## Installation

```bash
tar xzf cousin-runner-v2.tar.gz
cd cousin
bash install.sh
```

## Démarrage

```bash
cousin web          # serveur + navigateur → http://localhost:11435
cousin serve        # serveur seul (foreground)
cousin list         # modèles installés
cousin pull bartowski/Qwen2.5-0.5B-Instruct-GGUF
cousin run SmolLM2-135M-Instruct-Q4_K_M     # chat terminal
cousin ps           # runners actifs
cousin show <modèle>   # metadata GGUF
cousin rm <modèle>     # supprimer
cousin stop         # arrêter les runners
```

## WebGUI

Onglets : **Chat** (interface de conversation), **Pull** (recherche + téléchargement HuggingFace), **Status** (identité, runners, ports), **Mémoire** (souvenirs persistants).

## Identité

| | Cousin | Ollama |
|---|---|---|
| Port | **11435** | 11434 |
| Home | `~/.cousin` | `~/.ollama` |
| Binaire | `cousin` | `ollama` |
| API | Ollama-compatible | — |

Le port 11434 d'Ollama n'est **jamais** utilisé — refusé explicitement par le code.

*En hommage au créateur originel — Repose en paix.*
